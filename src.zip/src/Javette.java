
public class Javette extends Perso {
	public void changeDirection() {
		System.out.println("Javette est prisonnière! elle ne peut pas se déplacer.");
	}
}
